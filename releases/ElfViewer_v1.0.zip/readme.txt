History:
1.0 : first public release

Elf2Txt:
Use elf2txt to convert an elf file to text for easy comparison in TotalCommander or Beyond Compare.
Make a start button in TC:
Command: c:\totalcmd\Plugins\wlx\elfviewer\elf2txt.bat
Parameters: %P%N %T%M
Start path: C:\totalcmd\Plugins\wlx\elfviewer\

